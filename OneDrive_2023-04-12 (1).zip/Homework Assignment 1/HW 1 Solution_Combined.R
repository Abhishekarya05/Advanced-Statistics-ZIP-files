##################### HW 1: Advanced Statistics (BUAN 6359) ####################
# Group members: 
# Shehkar Vashist 
# Abhishek Arya 
# Manan Mistry 
# Piyush Yerpude
# Jyoti Sawal

#-------------------------------- Query 1 --------------------------------#

# Setting the Working Directory
setwd("C:/Users/SHEKHAR/Desktop/UTD MSBA Spring/Statistics 6359/HW 1")
rm(list=ls())

# Load the data set
workload <- read.csv("workload.csv")

# Adding a new variable with labels as given in the query
workload$Label <- factor(workload$Home.workload,
                         levels=c(1,2,3,4,5,6),
                         labels=c("Mom: Full time; Dad: Full time",
                                  "Mom: Part-time; Dad: Full time",
                                  "Mom: Not employed; Dad: Full time",
                                  "Mom: Full-time; Dad: Part-time or not employed",
                                  "Mom: Not employed; Dad: Not employed",
                                  "Other"))

n <- nrow(workload); n

# Frequency Distribution Table

library('dplyr')

options(digits = 4)
freq_table <- workload %>%
  group_by(Label)%>%
  summarise(Frequency=n())%>%
  arrange(desc(Frequency))%>%
  mutate('Relative Frequency' = Frequency/n); freq_table


# Bar chart of frequency distribution table

freq_count <- table(workload$Label); freq_count

barplot(freq_count,
        main = "Frequency Barplot",
        xlab = "Responses",
        ylab = "Frequency",
        ylim = c(0,800),
        border = "red" , col = "lightblue")


# Pie chart for relative frequency distribution table

pie_table <- round((freq_count/n)*100 ,1); pie_table
pie(pie_table,
    labels = paste(pie_table,"%", sep=""),
    main = "Relative Frequency Pie Chart",
    col = rainbow(length(pie_table)))

legend("topleft",
       c("Mom: Full time; Dad: Full time",
         "Mom: Part-time; Dad: Full time",
         "Mom: Not employed; Dad: Full time",
         "Mom: Full-time; Dad: Part-time or not employed",
         "Mom: Not employed; Dad: Not employed",
         "Other"),
       cex = 0.5,
       fill = rainbow(length(pie_table)))



# -------------------------------Query 2--------------------------------------#

rm(list=ls()) #Clear up the Working Environment 

# Load the MBA data set
MBA <- read.csv("MBA.csv")

MBA$DegName <- factor(MBA$Degree,
                      levels = c(1,2,3,4),
                      labels = c("BA",
                                 "B.Eng",
                                 "BBA",
                                 "Other"))
MBA$UniCodes <- factor(MBA$University,
                       levels = c(1,2,3,4),
                       labels = c("Uni 1",
                                  "Uni 2",
                                  "Uni 3",
                                  "Uni 4"))


levels(MBA$DegName)
levels(MBA$UniCodes)

# Cross Classification Tables:

n <- nrow(MBA) ; n

addmargins(table(MBA$UniCodes , MBA$DegName))


# Row Relative frequency Table

table(MBA$UniCodes , MBA$DegName) %>%
  prop.table(margin = 1)%>%
  round(2)

#  Column Relative Frequencies

table(MBA$UniCodes , MBA$DegName) %>%
  prop.table(margin = 2)%>%
  round(2)

# Creating a side by side bar graph

MBA_count <- table(MBA$DegName , MBA$UniCodes) ; MBA_count
barplot(MBA_count,
        main = "Two Dimensional Bar graph",
        xlab = "Universities",
        ylab = "Frequency",
        col = c("darkblue","red","green","yellow"),
        legend = rownames(MBA_count),
        beside = T)



# ----------------------------------Query 3-----------------------------------#
rm(list = ls())
df1 <- read.csv("GSS2014.csv")
df1.EDU <- subset(df1 , select = EDUC)

hist(df1.EDU$EDUC,
     breaks=10, #Define different Number of Breaks.
     freq=T,#freq=F --> hist of rel freq,comment out ylim,ylab,and labels.
     main="Histogram of American's Education Years in 2014",
     xlab="Education Years",
     ylab="Frequency",
     labels=T,#label the values
     xlim=c(0,23),
     ylim=c(0,1000),
     col="grey",
     border="red",
     las=1,#rotate the value of y-axis
     )

# ----------------------------Query 4-----------------------------------------#

rm(list = ls())
om <- read.csv("OlympicsMedal.csv")

can <- ts(om$Canada,start = c(1),end = c(22),frequency = 1)
US <- ts(om$United.States, start = c(1), end = c(22) , frequency = 1)

require(graphics)
ts.plot(can , US,
        gpars = list(xaxt = 'n'),
        main = "No. of medals won at olympics",
        ylab = "Count of Medals won",
        xlab = "Year",
        lty = c(1:2),
        type = "o",
        col = c("red","blue"),
        lwd = 1.5)

axis(1, om$Year , at = seq(from = 1 , by = 1 , length = 22))
legend('topleft',legend=c("Canada","USA"),col=c("red","blue"),
       lwd=2,lty=1:3,bty="n")


# -----------------------------Query 5----------------------------------------#

rm(list = ls())

df1 <- read.csv("GSS2014.csv")


df1_sub1 <- subset(df1 , select = c(CASEID , INCOME , EDUC))
df1_sub1$INCOME <- as.numeric(gsub(",","",df1_sub1$INCOME))


# Calculating mean and median of annual income 

mean(df1_sub1$INCOME , na.rm = TRUE)
median(df1_sub1$INCOME , na.rm = T)

# Since th mean is greater than mean it is left skewed

# Boxplot of INCOME
boxplot(df1_sub1$INCOME,
        main = "Boxplot for INCOME",
        xlab = "Income in $",
        col = "lightblue",
        horizontal = T)

#  Range of the INCOME distribution 

Range <- max(df1_sub1$INCOME , na.rm = T) - min(df1_sub1$INCOME , na.rm = T); Range

#  Standard Deviation

sd(df1_sub1$INCOME, na.rm = T)

#  Coefficient of variation

CV <- sd(df1_sub1$INCOME, na.rm = T) / mean(df1_sub1$INCOME , na.rm = T) ; CV

#  Quartiles 

quantile(df1_sub1$INCOME , na.rm = T)

#  Scatter plot
plot(df1_sub1$EDUC, df1_sub1$INCOME,
     main = "Scatterplot of INCOME and EDUC",
     ylab = "Income in $",
     xlab = "Education years",
     col = "red",
     pch = 16)


# Correlation coefficient

cov(df1_sub1$EDUC , df1_sub1$INCOME , use = "pairwise")
cor(df1_sub1$EDUC , df1_sub1$INCOME , use = "pairwise")



# *******************************End of HW 1************************************







