##################### HW 3: Advanced Statistics (BUAN 6359) ####################
# Group members: 
# Shekhar Vashist 
# Abhishek Arya 
# Manan Mistry 
# Piyush Yerpude
# Jyoti Sawal

# ---------------------------------Question 1-----------------------------------
rm(list=ls())

# Query a
a<- 100
b<- 150
M1 <- (a+b)/2 ; M1
SD1 <- ((1/12)*(b-a)^2)^(1/2) ; SD1

# Query b
punif(110 , min = 100 , max = 150 , lower.tail = F)

#  Query c
punif(135 , min = 100 , max = 150) - punif(120 , min = 100 , max = 150)

# Query d
punif(122 , min = 100 , max = 150 )

# --------------------------------Question 2------------------------------------
rm(list = ls())

lambda <- 0.008

# Query a

Mean <- 1/lambda ; Mean
SD <- 1/lambda ; SD

# query b

pexp(140 , lambda) - pexp(120 , lambda)

# query c.1
pexp(125 , lambda , lower.tail = F)

# Query c.2
pexp(125 , lambda)

# Query c.3
1 - (pexp(125 , lambda) + pexp(125 , lambda , lower.tail = F))

# -------------------------------Question 3-------------------------------------

rm(list = ls())
mean <- 7.3
SD <- 2.4

# Query a

pnorm(12 , mean , SD) - pnorm(6 , mean , SD)

# Query b

pnorm(9 , mean, SD , lower.tail = F)

# Query c

pnorm(5 , mean , SD)












