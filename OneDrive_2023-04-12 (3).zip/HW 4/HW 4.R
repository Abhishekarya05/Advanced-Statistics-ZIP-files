##################### HW 4: Advanced Statistics (BUAN 6359) ####################
# Group members: 
# Shekhar Vashist 
# Abhishek Arya 
# Manan Mistry 
# Piyush Yerpude
# Jyoti Sawal

# ---------------------------------Question 1-----------------------------------
rm(list=ls())

n <- 90
Ybar <- 39.50
sd <- 12

# Query a (Constructing a 95% C.I.)
SEYbar <- sd/(n^(1/2))
Z <- qnorm(0.975)
ME <- SEYbar * Z
UP_CI <- Ybar + ME ; UP_CI
LO_CI <- Ybar - ME ; LO_CI


# Query b
# Here we should have the ME as $2 and we need to calculate the least number of consumers to be surveyed to achieve this
ME_2 <- 2

new_n <- ((Z*sd)/ME_2)^2
new_n

# Query c: build a hypothesis test
# H0: Mu = 38
# H1: Mu > 38

Mu <- 38

z_stat <- (Ybar - Mu)/(SEYbar)

p <- pnorm(z_stat , lower.tail = F)
p

#  Since p value is not less than alpha hence we do not reject the null hypothesis.

# ---------------------------------Question 2-----------------------------------
rm(list=ls())
A <- c(68 , 77 , 82 , 85)
B <- c(53, 64, 71)

# Query a: Setting up hypothesis

# Ho: 𝛿 = 0
# H1: 𝛿 <> 0

# Query b:

A.bar <- mean(A)
B.bar <- mean(B)

delta <- A.bar - B.bar ; delta

# Query 3 and 4
scores <-c(68,77,82,85,53,64,71)
groupA <-combn(scores,4)
groupB <-apply(groupA,2, function(x) scores[! (scores %in% x) ] )
colnames(groupA) <-colnames(groupB) <-paste("G",1:35,sep="")

diff <- colMeans(groupA) - colMeans(groupB)
diff


# Query 5

k1 <- sum(abs(diff) >= delta)


# Query 6

p.value <- k1/length(diff)
p.value 

# Query 7: Conclusion
# Since the p value is greater than the alpha hence we do not reject the null hypothesis, which means there is no treatment effect in this random experiment.



# ---------------------------------Question 3-----------------------------------
rm(list=ls())
require(mosaic)

nfd <- c(-6,0,1,2,-3,-4,2)
fd <- c(8,12,10,14,2,0,0)

# Following calculation are for Non Fish oil Diet (nfd)
# ----------------------------------------------------

# Query a

nfd.bar <- mean(nfd) ; nfd.bar
sd.nfd <- sd(nfd); sd.nfd
n <- length(nfd) ; n
df.nfd <- n-1 ; df.nfd

#  Query b

se.nfd <- sd.nfd/sqrt(n) ; se.nfd

#  Query c: 95% CI

alpha = 0.05
t.c = qt(1-alpha/2, n-1); t.c 
me = t.c*se.nfd; me
LL = nfd.bar - me; LL
UL = nfd.bar + me; UL

# Query d: H0: Mu = 0 | H1: Mu <> 0

t.ratio = (nfd.bar - 0)/(sd.nfd/sqrt(n)); t.ratio
p.value = 2*pt(abs(t.ratio), n-1, lower.tail = F); p.value

# Using command approach

t.test(nfd, mu=0, conf.level = 0.95, alternative="two.side")

# Since the p-value is greater than alpha hence do not reject null hypothesis

# Query e: Repeating all steps for Fish oil Diet (fd)

fd.bar <- mean(fd) ; fd.bar
sd.fd <- sd(fd); sd.fd
n.fd <- length(fd) ; n.fd
df.fd <- n.fd-1 ; df.fd


se.fd <- sd.fd/sqrt(n.fd) ; se.fd


alpha = 0.05
t.c_fd = qt(1-alpha/2, n.fd-1); t.c_fd 
me_fd = t.c_fd*se.fd; me_fd
LL_fd = fd.bar - me_fd; LL_fd
UL_fd = fd.bar + me_fd; UL_fd


t.ratio_fd = (fd.bar - 0)/(sd.fd/sqrt(n.fd)); t.ratio_fd
p.value_fd = 2*pt(abs(t.ratio_fd), n.fd-1, lower.tail = F); p.value_fd



t.test(fd, mu=0, conf.level = 0.95, alternative="two.side")




