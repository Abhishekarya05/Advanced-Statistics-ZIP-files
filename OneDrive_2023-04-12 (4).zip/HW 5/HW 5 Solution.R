##################### HW 5: Advanced Statistics (BUAN 6359) ####################
# Group members: 
# Shekhar Vashist 
# Abhishek Arya 
# Manan Mistry 
# Piyush Yerpude
# Jyoti Sawal

# ---------------------------------Question 1-----------------------------------
rm(list=ls())

library(mosaic)

person <- c('A','B','C','D','E','F') 
weight_before <- c(165, 172, 181, 185, 168, 175)
weight_after <- c(143, 151, 156, 161, 152, 154)

df <- data.frame(person, weight_before, weight_after)
df

summary(df)

#Calculate the difference b/w the test score for each pair:
df$diff<- df$weight_after - df$weight_before
favstats_1<- favstats(~diff, data=df); favstats_1
densityplot(~diff, data=df, xlab = "Weight Difference")

# H0: mu.d=0 vs. H1: mu.d<0
mu=0 #based on H0
d.bar<- mean(df$diff); d.bar  # mean(d)
sd.d<- sd(df$diff); sd.d    # SD(d)
n = nrow(df); n                 # No. of observation
SE.d = sd.d/sqrt(n); SE.d
t.ratio = (d.bar - mu)/SE.d; t.ratio  # Calculate t-statistic
p.value = pt(abs(t.ratio), n-1, lower.tail = F); p.value

# Command Approach
t.test(df$diff, mu=0, conf.level = .95, alternative = "less")


# ---------------------------------Question 2-----------------------------------
rm(list=ls())

setwd("C:/Users/SHEKHAR/Desktop/UTD MSBA Spring/Statistics 6359/HW 5")
library(mosaic)

data <- read.csv('ORingData.csv')

# Query 1

favstat_2<- favstats(~temp, data=data); favstat_2
favstat_3<- favstats(~oring_damage, data=data); favstat_3

# proportion of flights with Oring damage:

prop <- (sum(data$oring_damage > 0) / nrow(data)) * 100 ; prop

# Query 2

data$status <- ifelse(data$oring_damage == 0, "No Damage Group", "Damage Group")
favstat_4<- favstats(temp~status, data=data); favstat_4

boxplot(temp~status, data=data, 
        ylab="Temp",
        xlab="Oring Damage Status",
        col="orange")

cbind(by(data$temp,data$status,mean),
      by(data$temp,data$status,sd), by(data$temp,data$status,length))

densityplot(~temp, groups=status, auto.key=TRUE, data=data)

# Query 3
n.damage = favstat_4$n[favstat_4$status=="Damage Group"]; n.damage
n.no_damage = favstat_4$n[favstat_4$status=="No Damage Group"]; n.no_damage

sd.damage = favstat_4$sd[favstat_4$status=="Damage Group"]; sd.damage
sd.no_damage = favstat_4$sd[favstat_4$status=="No Damage Group"]; sd.no_damage 

Y.bar.damage = favstat_4$mean[favstat_4$status=="Damage Group"]; Y.bar.damage
Y.bar.no_damage = favstat_4$mean[favstat_4$status=="No Damage Group"]; Y.bar.no_damage


Sp=sqrt(((n.damage - 1)*sd.damage^2 + (n.no_damage - 1)*sd.no_damage^2)/
          (n.damage + n.no_damage -2)); Sp 
SE=Sp*sqrt(1/n.damage + 1/n.no_damage); SE # Standard error
v=n.damage + n.no_damage - 2; v #degrees of freedom
t.ratio = ((Y.bar.no_damage - Y.bar.damage)- 0 )/SE; t.ratio
pvalue<- 2*pt(abs(t.ratio), v, lower.tail = F);pvalue

# Command Approach
t.test(temp~status, var.equal=TRUE, alternative="two.side", data=data)

# Query 4
alpha<- .05
t.c<- qt(1 - alpha/2, v); t.c
me<- t.c*SE; me
LL<- (Y.bar.no_damage-Y.bar.damage) - me; LL
UL<- (Y.bar.no_damage-Y.bar.damage) + me; UL


# ---------------------------------Question 3-----------------------------------
rm(list=ls())

df <- read.csv('textmessages.csv')

df$female <- ifelse(df$female == 1 , "female", 'male')

# Query 1

favstat_5 <- favstats(texts~female, data=df); favstat_5

# Query 2

t.test(texts~female,var.equal=TRUE,alternative="two.side",data=df) 

# Query 4 (Graphical representation)
#Density Plot
densityplot(~texts | female, data=df) # Also gf_density()
gf_density(~texts | female, data=df)

#Box Plot
bwplot(texts~female, data=df, 
       col="red", cex.axis=1.2, cex.lab=1.2,
       main="Box Plot (Original Scale)",
       ylab="texts"
)

#Normal Quantile Plot 
gf_qq(~ texts | female, col="red", data=df) %>%  
  gf_qqline(col="blue", lwd=1)

boxplot(texts~female, data=df, 
        col="lightgreen", cex.axis=1.2, cex.lab=1.2,
        main="Box Plot (Original Scale)",
        ylab="texts"
)

#Log-transformation
df=transform(df, logtexts=log(texts))

boxplot(logtexts ~ female, data=df, 
        col="skyblue", cex.axis=1.2, cex.lab=1.2,
        main="Box Plot (Logged Data)",
        ylab="ln(texts)"
) 
densityplot(~logtexts | female, data=df, xlab="log(texts)") 

gf_qq(~ logtexts | female, col="red", data=df) %>% gf_qqline(col="blue", lwd=1.2)

# Query 5

favstats_log<- favstats(logtexts ~ female, data=df)
favstats_log

# Query 6


t.test(logtexts~female,var.equal=TRUE,alternative="two.side",data=df) 

# Query 7

Z_m.bar=favstats_log$mean[favstats_log$female=="male"]; Z_m.bar 
Z_f.bar=favstats_log$mean[favstats_log$female=="female"]; Z_f.bar 

Medians_ratio=exp(Z_f.bar - Z_m.bar); Medians_ratio

# Query 9
alpha <- 0.05

n_M=favstats_log$n[favstats_log$female=="male"]; n_M
n_F=favstats_log$n[favstats_log$female=="female"]; n_F

sd.Z_m=favstats_log$sd[favstats_log$female=="male"]; sd.Z_m 
sd.Z_f=favstats_log$sd[favstats_log$female=="female"]; sd.Z_f

Sp <- sqrt(((n_M - 1)*sd.Z_m^2 + (n_F - 1)*sd.Z_f^2)/(n_M+n_F-2)); Sp # Pooled SD
SE <- Sp*sqrt(1/n_F + 1/n_M); SE # Standard Error of Add_TE



t_c=qt(1 - alpha/2, n_F + n_M - 2); t_c
me=t_c*SE ; me

Add_TE=Z_f.bar - Z_m.bar; Add_TE

Add_TE_LL=Add_TE - me; Add_TE_LL
Add_TE_UL=Add_TE + me; Add_TE_UL 

# Command approach:
t.test(logtexts~female,var.equal=TRUE,alternative="two.side",data=df) 


Mult_TE=exp(Add_TE); Mult_TE

Mult_TE_LL=exp(Add_TE_LL); Mult_TE_LL
Mult_TE_UL =exp(Add_TE_UL); Mult_TE_UL








